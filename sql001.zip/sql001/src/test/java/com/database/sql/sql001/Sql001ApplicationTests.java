package com.database.sql.sql001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sql001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
