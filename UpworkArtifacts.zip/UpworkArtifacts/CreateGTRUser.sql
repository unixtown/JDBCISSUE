USE [GTR]
GO

/****** Object:  User [gtr]    Script Date: 8/20/2022 3:08:06 PM ******/
DROP USER [gtr]
GO

/****** Object:  User [gtr]    Script Date: 8/20/2022 3:08:06 PM ******/
CREATE USER [gtr] FOR LOGIN [gtr] WITH DEFAULT_SCHEMA=[dbo]
GO

