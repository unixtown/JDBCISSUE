package com.database.sql.sql001;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@RestController
public class sqlOperations {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String sqlOperationIndex(){
        return "Please select a valid API method";
    }

    @RequestMapping("/sqlOperationSelect")
    public int sqlOperationSelect(){
        // Perform db operation BEGIN

        String connectionUrl = "jdbc:sqlserver://127.0.0.1:1433;databaseName=GTR;trustServerCertificate=true";

        try (Connection con = DriverManager.getConnection(connectionUrl,"gtr","gtr"); Statement stmt = con.createStatement()) {
            String SQL = "SELECT [Qty],[Model],[Brand],[Id]  FROM [GTR].[dbo].[Stock]";

            ResultSet rs = stmt.executeQuery(SQL);

            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                System.out.println(rs.getString("Qty") + " " + rs.getString("Model"));
            }
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }

        // Perform db operation END


        return 0;
    }
}
