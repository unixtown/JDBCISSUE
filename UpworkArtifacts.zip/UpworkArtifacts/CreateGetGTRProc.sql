USE [GTR]
GO

/****** Object:  StoredProcedure [dbo].[GetGTR]    Script Date: 8/20/2022 3:08:58 PM ******/
DROP PROCEDURE [dbo].[GetGTR]
GO

/****** Object:  StoredProcedure [dbo].[GetGTR]    Script Date: 8/20/2022 3:08:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetGTR]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	

SELECT [Qty]
      ,[Model]
      ,[Brand]
      ,[Id]
  FROM [GTR].[dbo].[Stock]

END
GO

