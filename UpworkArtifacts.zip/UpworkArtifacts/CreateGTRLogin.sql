USE [master]
GO

/****** Object:  Login [gtr]    Script Date: 8/20/2022 3:08:29 PM ******/
DROP LOGIN [gtr]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [gtr]    Script Date: 8/20/2022 3:08:29 PM ******/
CREATE LOGIN [gtr] WITH PASSWORD=N'cQqkj0r8yntQHN8YM3CICrntb7UXRP4Km1HMkbFNuFM=', DEFAULT_DATABASE=[GTR], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

ALTER LOGIN [gtr] DISABLE
GO

