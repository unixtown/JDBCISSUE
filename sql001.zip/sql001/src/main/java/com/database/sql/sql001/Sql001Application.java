package com.database.sql.sql001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sql001Application {

	public static void main(String[] args) {
		SpringApplication.run(Sql001Application.class, args);
	}

}


